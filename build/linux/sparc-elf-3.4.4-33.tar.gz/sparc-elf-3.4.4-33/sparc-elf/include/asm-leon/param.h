#ifndef _LEON_ASMSPARC_PARAM_H
#define _LEON_ASMSPARC_PARAM_H

/* note: this is also defined in machine/param.h */
#define HZ		  100UL      /* Internal kernel timer frequency */
#define  CLOCK_TICK_RATE  1000000UL  /* Underlying HZ */

#endif
