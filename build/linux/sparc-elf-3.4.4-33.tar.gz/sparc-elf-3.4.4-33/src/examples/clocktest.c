#include <stdio.h>
#include <time.h>

int main(int c, char** v)
{
  clock_t time = clock();
  printf ("Hello, world!\n");
}

