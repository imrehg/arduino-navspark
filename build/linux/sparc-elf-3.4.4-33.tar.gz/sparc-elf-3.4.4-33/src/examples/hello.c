#include <stdio.h>

main() {
  printf("Hello\n");
}
